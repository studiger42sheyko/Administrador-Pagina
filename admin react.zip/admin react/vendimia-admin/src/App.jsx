// src/App.jsx
import React from "react";
import axios from "axios";
import "./App.css";

// --- Componentes ---
const Header = () => (
  <header>
    <h1>Panel Administrativo – Vendimia Viva</h1>
    <p>Gestión interna de candidatas, votos y resultados</p>
    <div className="admin-indicator">
      <i className="fas fa-user-shield"></i> Modo Administrador
    </div>
  </header>
);

const Sidebar = ({ active, setActive }) => {
  const items = [
    { name: "Dashboard", icon: "fas fa-tachometer-alt" },
    { name: "Candidatas", icon: "fas fa-user-plus" },
    { name: "Votos", icon: "fas fa-vote-yea" },
    { name: "Resultados", icon: "fas fa-chart-bar" },
    { name: "Configuración", icon: "fas fa-cog" },
    { name: "Cerrar Sesión", icon: "fas fa-sign-out-alt" },
  ];

  return (
    <nav className="sidebar">
      <ul>
        {items.map((item) => (
          <li
            key={item.name}
            className={active === item.name ? "active" : ""}
            onClick={() => setActive(item.name)}
          >
            <i className={item.icon}></i> {item.name}
          </li>
        ))}
      </ul>
    </nav>
  );
};

const Dashboard = () => (
  <div className="dashboard-section">
    <div className="dashboard-cards">
      <div className="card candidatas">
        <i className="fas fa-crown"></i>
        <h3>15</h3>
        <p>Candidatas Registradas</p>
      </div>
      <div className="card votos">
        <i className="fas fa-vote-yea"></i>
        <h3>2,847</h3>
        <p>Votos Totales</p>
      </div>
      <div className="card usuarios">
        <i className="fas fa-users"></i>
        <h3>3</h3>
        <p>Administradores</p>
      </div>
      <div className="card actividad">
        <i className="fas fa-clock"></i>
        <h3>5</h3>
        <p>Actividades Recientes</p>
      </div>
    </div>
  </div>
);

const FormCandidata = () => {
  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    // Aquí enviás los datos a tu servidor Express
    try {
      await axios.post("http://localhost:5000/candidatas", {
        nombre: formData.get("nombre"),
        departamento: formData.get("departamento"),
        edad: formData.get("edad"),
        descripcion: formData.get("descripcion"),
      });
      alert("Candidata guardada correctamente");
      e.target.reset();
    } catch (error) {
      console.error(error);
      alert("Error al guardar la candidata");
    }
  };

  return (
    <section className="formulario">
      <h2>
        <i className="fas fa-user-plus"></i> Agregar Candidata
      </h2>
      <form onSubmit={handleSubmit}>
        <label>Nombre:</label>
        <input type="text" name="nombre" required placeholder="Ingrese nombre completo" />

        <label>Departamento:</label>
        <select name="departamento" required>
          <option value="">Seleccione un departamento</option>
          <option value="Godoy Cruz">Godoy Cruz</option>
          <option value="Maipú">Maipú</option>
          <option value="Guaymallén">Guaymallén</option>
          <option value="Luján de Cuyo">Luján de Cuyo</option>
          <option value="Las Heras">Las Heras</option>
        </select>

        <label>Edad:</label>
        <input type="number" name="edad" min="18" max="35" required />

        <label>Descripción:</label>
        <textarea name="descripcion" rows="3" placeholder="Breve descripción de la candidata"></textarea>

        <div className="form-actions">
          <button type="submit">
            <i className="fas fa-save"></i> Guardar Candidata
          </button>
          <button type="reset" className="secondary">
            <i className="fas fa-undo"></i> Limpiar
          </button>
        </div>
      </form>
    </section>
  );
};

const FormVoto = () => {
  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    try {
      await axios.post("http://localhost:5000/votos", {
        id_candidata: formData.get("id_candidata"),
        votos: formData.get("votos"),
        tipo_voto: formData.get("tipo_voto"),
      });
      alert("Voto registrado correctamente");
      e.target.reset();
    } catch (error) {
      console.error(error);
      alert("Error al registrar el voto");
    }
  };

  return (
    <section className="formulario">
      <h2>
        <i className="fas fa-vote-yea"></i> Registrar Voto
      </h2>
      <form onSubmit={handleSubmit}>
        <label>Candidata:</label>
        <select name="id_candidata" required>
          <option value="">Seleccione una candidata</option>
          <option value="1">Ana López (Godoy Cruz)</option>
          <option value="2">Camila Torres (Maipú)</option>
          <option value="3">María González (Guaymallén)</option>
        </select>

        <label>Cantidad de votos:</label>
        <input type="number" name="votos" min="1" required placeholder="Número de votos" />

        <label>Tipo de voto:</label>
        <select name="tipo_voto">
          <option value="presencial">Presencial</option>
          <option value="digital">Digital</option>
        </select>

        <div className="form-actions">
          <button type="submit">
            <i className="fas fa-plus-circle"></i> Registrar Voto
          </button>
          <button type="reset" className="secondary">
            <i className="fas fa-undo"></i> Limpiar
          </button>
        </div>
      </form>
    </section>
  );
};

const TablaCandidatas = () => (
  <section className="tabla">
    <h2>
      <i className="fas fa-list"></i> Candidatas Registradas
    </h2>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Nombre</th>
          <th>Departamento</th>
          <th>Edad</th>
          <th>Descripción</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td>Ana López</td>
          <td>Godoy Cruz</td>
          <td>23</td>
          <td>Representante entusiasta y amante del vino mendocino.</td>
          <td className="actions">
            <button className="edit">
              <i className="fas fa-edit"></i>
            </button>
            <button className="delete">
              <i className="fas fa-trash"></i>
            </button>
          </td>
        </tr>
        <tr>
          <td>2</td>
          <td>Camila Torres</td>
          <td>Maipú</td>
          <td>25</td>
          <td>Apasionada por la cultura vitivinícola de Mendoza.</td>
          <td className="actions">
            <button className="edit">
              <i className="fas fa-edit"></i>
            </button>
            <button className="delete">
              <i className="fas fa-trash"></i>
            </button>
          </td>
        </tr>
        <tr>
          <td>3</td>
          <td>María González</td>
          <td>Guaymallén</td>
          <td>22</td>
          <td>Estudiante de enología con amplio conocimiento vitivinícola.</td>
          <td className="actions">
            <button className="edit">
              <i className="fas fa-edit"></i>
            </button>
            <button className="delete">
              <i className="fas fa-trash"></i>
            </button>
          </td>
        </tr>
      </tbody>
    </table>
  </section>
);

// --- App principal ---
function App() {
  const [active, setActive] = React.useState("Dashboard");

  const renderContent = () => {
    switch(active) {
      case "Dashboard":
        return <Dashboard />;
      case "Candidatas":
        return (
          <div className="section-container">
            <FormCandidata />
            <TablaCandidatas />
          </div>
        );
      case "Votos":
        return (
          <div className="section-container">
            <FormVoto />
          </div>
        );
      case "Resultados":
        return (
          <div className="section-container">
            <div className="formulario">
              <h2><i className="fas fa-chart-bar"></i> Resultados</h2>
              <p>Próximamente: Gráficos y estadísticas de votación</p>
            </div>
          </div>
        );
      case "Configuración":
        return (
          <div className="section-container">
            <div className="formulario">
              <h2><i className="fas fa-cog"></i> Configuración</h2>
              <p>Configuración del sistema administrativo</p>
            </div>
          </div>
        );
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="app-container">
      <Header />
      <div className="content-wrapper">
        <Sidebar active={active} setActive={setActive} />
        <main className="main-content">
          {renderContent()}
        </main>
      </div>
      <footer>
        <p>© 2025 Vendimia Viva | Panel de Administración</p>
      </footer>
    </div>
  );
}

export default App;