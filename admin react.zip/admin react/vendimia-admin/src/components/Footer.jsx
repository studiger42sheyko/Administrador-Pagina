export default function Footer() {
  return <footer className="footer">© 2025 Vendimia Viva | Panel de Administración</footer>;
}
