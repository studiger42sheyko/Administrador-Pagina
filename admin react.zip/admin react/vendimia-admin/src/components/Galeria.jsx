export default function Galeria() {
  return (
    <section id="galeria" className="galeria">
      <h2>Celebración y Tradición</h2>
      <div className="imagenes">
        <img src="/vendimia1.jpg" alt="Vendimia desfile" />
        <img src="/vendimia2.jpg" alt="Cosecha de uvas" />
        <img src="/vendimia3.jpg" alt="Elección de la reina" />
      </div>
      <p>
        La Fiesta Nacional de la Vendimia celebra el trabajo de los viñateros mendocinos y la cultura del vino,
        siendo una de las festividades más reconocidas del país.
      </p>
    </section>
  );
}
