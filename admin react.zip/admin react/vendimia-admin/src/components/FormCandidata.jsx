import { useState } from "react";
import axios from "axios";

export default function FormCandidata() {
  const [form, setForm] = useState({ nombre: "", departamento: "", edad: "", descripcion: "" });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/api/candidatas", form);
      alert("✅ Candidata registrada con éxito");
      setForm({ nombre: "", departamento: "", edad: "", descripcion: "" });
    } catch (error) {
      alert("❌ Error al registrar candidata");
    }
  };

  return (
    <section className="formulario">
      <h2>Agregar Candidata</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="nombre" value={form.nombre} onChange={handleChange} placeholder="Nombre completo" required />
        <select name="departamento" value={form.departamento} onChange={handleChange} required>
          <option value="">Seleccione un departamento</option>
          <option value="Godoy Cruz">Godoy Cruz</option>
          <option value="Maipú">Maipú</option>
          <option value="Guaymallén">Guaymallén</option>
          <option value="Luján de Cuyo">Luján de Cuyo</option>
          <option value="Las Heras">Las Heras</option>
        </select>
        <input type="number" name="edad" value={form.edad} onChange={handleChange} placeholder="Edad" min="18" max="35" required />
        <textarea name="descripcion" value={form.descripcion} onChange={handleChange} placeholder="Descripción"></textarea>
        <button type="submit">Guardar Candidata</button>
      </form>
    </section>
  );
}
