export default function TablaCandidatas({ candidatas }) {
  return (
    <section className="tabla">
      <h2>Candidatas Registradas</h2>
      <table>
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Departamento</th>
            <th>Edad</th>
            <th>Descripción</th>
          </tr>
        </thead>
        <tbody>
          {candidatas.map(c => (
            <tr key={c._id}>
              <td>{c.nombre}</td>
              <td>{c.departamento}</td>
              <td>{c.edad}</td>
              <td>{c.descripcion}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}
