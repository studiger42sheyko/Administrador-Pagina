import { useState } from "react";
import axios from "axios";

export default function FormVoto({ candidatas }) {
  const [form, setForm] = useState({ id_candidata: "", votos: 1, tipo_voto: "presencial" });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/api/votos", form);
      alert("✅ Voto registrado con éxito");
      setForm({ id_candidata: "", votos: 1, tipo_voto: "presencial" });
    } catch (error) {
      alert("❌ Error al registrar voto");
    }
  };

  return (
    <section className="formulario">
      <h2>Registrar Voto</h2>
      <form onSubmit={handleSubmit}>
        <select name="id_candidata" value={form.id_candidata} onChange={handleChange} required>
          <option value="">Seleccione una candidata</option>
          {candidatas.map(c => (
            <option key={c._id} value={c._id}>{c.nombre} ({c.departamento})</option>
          ))}
        </select>
        <input type="number" name="votos" value={form.votos} onChange={handleChange} min="1" required />
        <select name="tipo_voto" value={form.tipo_voto} onChange={handleChange}>
          <option value="presencial">Presencial</option>
          <option value="digital">Digital</option>
        </select>
        <button type="submit">Registrar Voto</button>
      </form>
    </section>
  );
}
