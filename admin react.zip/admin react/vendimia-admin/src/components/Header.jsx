export default function Header() {
  return (
    <header className="header">
      <h1>Panel Administrativo – Vendimia Viva</h1>
      <p>Gestión interna de candidatas, votos y resultados</p>
    </header>
  );
}
